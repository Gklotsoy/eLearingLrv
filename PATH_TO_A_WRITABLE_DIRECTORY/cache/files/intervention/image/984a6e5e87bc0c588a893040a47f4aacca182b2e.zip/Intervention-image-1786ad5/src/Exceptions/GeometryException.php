<?php

declare(strict_types=1);

namespace Intervention\Image\Exceptions;

class GeometryException extends RuntimeException
{
}
